package Signup;

import java.awt.*;
import Login.window;
import java.awt.Color;
import javax.swing.*;
import java.awt.geom.RoundRectangle2D;
import jpop.Jpopf;

public class Sign extends javax.swing.JFrame {
private javax.swing.JPopupMenu calendarPopup;
private java.util.Date selectedDate; // To store the selected date
private javax.swing.JDialog calendarDialog; // Dialog to display the calendar

    public Sign() {
        // Initialize components and set frame properties
        initComponents();
        initializeCalendarDialog();
        
        // Set the frame to have rounded corners
        int arcWidth = 20; // Width of the rounded corners
        int arcHeight = 20; // Height of the rounded corners
        this.setShape(new RoundRectangle2D.Double(0, 0, this.getWidth(), this.getHeight(), arcWidth, arcHeight));

        // Add a window listener to handle resizing
        this.addComponentListener(new java.awt.event.ComponentAdapter() {
            @Override
            public void componentResized(java.awt.event.ComponentEvent e) {
                setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), arcWidth, arcHeight));
            }
        });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        sidedddd1 = new swing.sidedddd();
        gruPanel2 = new swing.GruPanel();
        iconplaced = new swing.RoundPanel();
        home = new javax.swing.JButton();
        dashboard = new javax.swing.JButton();
        result = new javax.swing.JButton();
        conserved = new javax.swing.JButton();
        tips = new javax.swing.JButton();
        setting = new javax.swing.JButton();
        Logout = new javax.swing.JButton();
        gruPanel1 = new swing.GruPanel();
        upperpane = new swing.GruPanel();
        quit = new javax.swing.JButton();
        notif = new javax.swing.JButton();
        menu = new javax.swing.JButton();
        dashlab2 = new javax.swing.JLabel();
        Tabunder = new javax.swing.JPanel();
        tab = new javax.swing.JTabbedPane();
        hometabb = new javax.swing.JPanel();
        Homing = new swing.conserved();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();
        ressss1 = new swing.ressss();
        JHis = new javax.swing.JButton();
        sidedddd2 = new swing.sidedddd();
        Jcur = new javax.swing.JButton();
        Jhelp = new javax.swing.JButton();
        dyk = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        darkmode = new javax.swing.JCheckBox();
        white2 = new swing.white();
        white1 = new swing.white();
        white3 = new swing.white();
        white4 = new swing.white();
        ressss5 = new swing.ressss();
        feedback3 = new swing.feedback();
        ressss3 = new swing.ressss();
        white7 = new swing.white();
        feedback5 = new swing.feedback();
        feedback6 = new swing.feedback();
        jPanel1 = new javax.swing.JPanel();
        Dashhh = new swing.conserved();
        circleee1 = new swing.circleee();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        conserved1 = new swing.conserved();
        jLabel3 = new javax.swing.JLabel();
        white5 = new swing.white();
        white8 = new swing.white();
        Resultt = new swing.conserved();
        tiwat = new javax.swing.JLabel();
        t1 = new javax.swing.JScrollPane();
        TA1 = new javax.swing.JTextArea();
        t2 = new javax.swing.JScrollPane();
        TA2 = new javax.swing.JTextArea();
        t3 = new javax.swing.JScrollPane();
        TA3 = new javax.swing.JTextArea();
        Select = new javax.swing.JButton();
        daily = new javax.swing.JLabel();
        weekly = new javax.swing.JLabel();
        monthly = new javax.swing.JLabel();
        topround2 = new swing.topround();
        jButton9 = new javax.swing.JButton();
        getresult = new javax.swing.JButton();
        white6 = new swing.white();
        Wotco = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        calendar2 = new raven.calendar.Calendar();
        white9 = new swing.white();
        topround3 = new swing.topround();
        Cons = new swing.conserved();
        Tips = new swing.conserved();
        jButton1 = new javax.swing.JButton();
        sharpsidesett1 = new swing.sharpsidesett();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(10, 100));
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        sidedddd1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(sidedddd1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 40, 90, 90));
        getContentPane().add(gruPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 190, 90));

        iconplaced.setBackground(new java.awt.Color(0, 0, 0));
        iconplaced.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        home.setFont(new java.awt.Font("Wonderful Future", 0, 20)); // NOI18N
        home.setForeground(new java.awt.Color(255, 255, 255));
        home.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/home_10079449.png"))); // NOI18N
        home.setText("home");
        home.setBorder(null);
        home.setContentAreaFilled(false);
        home.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        home.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        home.setIconTextGap(5);
        home.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/home_10079155.png"))); // NOI18N
        home.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/home_10080464.png"))); // NOI18N
        home.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                homeMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                homeMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                homeMouseReleased(evt);
            }
        });
        iconplaced.add(home, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 70, -1, -1));

        dashboard.setFont(new java.awt.Font("Wonderful Future", 0, 20)); // NOI18N
        dashboard.setForeground(new java.awt.Color(255, 255, 255));
        dashboard.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/statistic_12617595.png"))); // NOI18N
        dashboard.setText("dashboard");
        dashboard.setBorder(null);
        dashboard.setContentAreaFilled(false);
        dashboard.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        dashboard.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        dashboard.setIconTextGap(2);
        dashboard.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/web_13961037.png"))); // NOI18N
        dashboard.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/web_13960847.png"))); // NOI18N
        dashboard.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dashboardMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                dashboardMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                dashboardMouseReleased(evt);
            }
        });
        dashboard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dashboardActionPerformed(evt);
            }
        });
        iconplaced.add(dashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 160, -1, -1));

        result.setFont(new java.awt.Font("Wonderful Future", 0, 20)); // NOI18N
        result.setForeground(new java.awt.Color(255, 255, 255));
        result.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/data-analysis_8991824.png"))); // NOI18N
        result.setText("convert");
        result.setBorder(null);
        result.setContentAreaFilled(false);
        result.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        result.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        result.setIconTextGap(5);
        result.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/chart_8451580.png"))); // NOI18N
        result.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/analytics_16971858.png"))); // NOI18N
        result.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                resultMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                resultMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                resultMouseReleased(evt);
            }
        });
        result.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resultActionPerformed(evt);
            }
        });
        iconplaced.add(result, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 250, -1, -1));

        conserved.setFont(new java.awt.Font("Wonderful Future", 0, 20)); // NOI18N
        conserved.setForeground(new java.awt.Color(255, 255, 255));
        conserved.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/hand_6128476.png"))); // NOI18N
        conserved.setText("conserved");
        conserved.setBorder(null);
        conserved.setContentAreaFilled(false);
        conserved.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        conserved.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        conserved.setIconTextGap(5);
        conserved.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/save-water (1).png"))); // NOI18N
        conserved.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/save-water_6714370.png"))); // NOI18N
        conserved.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                conservedMouseClicked(evt);
            }
        });
        conserved.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                conservedActionPerformed(evt);
            }
        });
        iconplaced.add(conserved, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 340, -1, -1));

        tips.setFont(new java.awt.Font("Wonderful Future", 0, 20)); // NOI18N
        tips.setForeground(new java.awt.Color(255, 255, 255));
        tips.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/bulb-icon.png"))); // NOI18N
        tips.setText("tips");
        tips.setBorder(null);
        tips.setBorderPainted(false);
        tips.setContentAreaFilled(false);
        tips.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        tips.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        tips.setIconTextGap(5);
        tips.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/electricity-icon.png"))); // NOI18N
        tips.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/lamp-icon.png"))); // NOI18N
        tips.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tipsMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tipsMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                tipsMouseReleased(evt);
            }
        });
        tips.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tipsActionPerformed(evt);
            }
        });
        iconplaced.add(tips, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 420, -1, -1));

        setting.setBackground(new java.awt.Color(102, 103, 255));
        setting.setFont(new java.awt.Font("Qilka", 1, 16)); // NOI18N
        setting.setForeground(new java.awt.Color(255, 255, 255));
        setting.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/settings_6047691.png"))); // NOI18N
        setting.setText("settings");
        setting.setBorder(null);
        setting.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        setting.setOpaque(true);
        setting.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/settings_6047806.png"))); // NOI18N
        setting.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/settings_6047806.png"))); // NOI18N
        setting.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                settingActionPerformed(evt);
            }
        });
        iconplaced.add(setting, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 520, 130, 40));

        Logout.setBackground(new java.awt.Color(66, 191, 183));
        Logout.setFont(new java.awt.Font("Qilka", 1, 16)); // NOI18N
        Logout.setForeground(new java.awt.Color(255, 255, 255));
        Logout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/logout_4562449.png"))); // NOI18N
        Logout.setText("Logout");
        Logout.setBorder(null);
        Logout.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Logout.setIconTextGap(12);
        Logout.setOpaque(true);
        Logout.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/log-out_4562493.png"))); // NOI18N
        Logout.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/log-out_4562493.png"))); // NOI18N
        Logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogoutActionPerformed(evt);
            }
        });
        iconplaced.add(Logout, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 560, 130, 40));

        gruPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        iconplaced.add(gruPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 600, 1160, 10));

        getContentPane().add(iconplaced, new org.netbeans.lib.awtextra.AbsoluteConstraints(-20, 90, 210, 610));

        upperpane.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        quit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/remove_5859923.png"))); // NOI18N
        quit.setBorder(null);
        quit.setBorderPainted(false);
        quit.setContentAreaFilled(false);
        quit.setIconTextGap(0);
        quit.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/remove (2).png"))); // NOI18N
        quit.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/remove (2).png"))); // NOI18N
        quit.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                quitMouseDragged(evt);
            }
        });
        quit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                quitMouseClicked(evt);
            }
        });
        upperpane.add(quit, new org.netbeans.lib.awtextra.AbsoluteConstraints(1203, 0, 30, 40));

        notif.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/notification.png"))); // NOI18N
        notif.setBorder(null);
        notif.setBorderPainted(false);
        notif.setContentAreaFilled(false);
        notif.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/notification (1).png"))); // NOI18N
        notif.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/notification (1).png"))); // NOI18N
        notif.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                notifActionPerformed(evt);
            }
        });
        upperpane.add(notif, new org.netbeans.lib.awtextra.AbsoluteConstraints(1169, 5, 30, 30));

        menu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/menu_8634944.png"))); // NOI18N
        menu.setBorder(null);
        menu.setBorderPainted(false);
        menu.setContentAreaFilled(false);
        menu.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/menu.png"))); // NOI18N
        menu.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/menu.png"))); // NOI18N
        menu.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                menuMouseDragged(evt);
            }
        });
        menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuActionPerformed(evt);
            }
        });
        upperpane.add(menu, new org.netbeans.lib.awtextra.AbsoluteConstraints(1135, 5, 30, 30));

        dashlab2.setFont(new java.awt.Font("Home Video", 2, 38)); // NOI18N
        dashlab2.setForeground(new java.awt.Color(255, 255, 255));
        dashlab2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        dashlab2.setText("HOME");
        upperpane.add(dashlab2, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 0, 260, 40));

        getContentPane().add(upperpane, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1240, 40));

        Tabunder.setBackground(new java.awt.Color(255, 255, 255));
        Tabunder.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tab.setBackground(new java.awt.Color(0, 51, 51));

        hometabb.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Homing.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        Homing.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 490, 920, 20));

        jLabel1.setFont(new java.awt.Font("Qilka", 0, 44)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("welcome back user!");
        Homing.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 20, 460, 70));
        Homing.add(ressss1, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, -30, 90, 90));

        JHis.setText("History");
        JHis.setBorder(null);
        JHis.setBorderPainted(false);
        JHis.setContentAreaFilled(false);
        JHis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JHisActionPerformed(evt);
            }
        });
        Homing.add(JHis, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 140, 580, 220));

        sidedddd2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        Homing.add(sidedddd2, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 20, 460, 70));

        Jcur.setText("current water consumption");
        Jcur.setBorder(null);
        Jcur.setBorderPainted(false);
        Jcur.setContentAreaFilled(false);
        Jcur.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        Jcur.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JcurActionPerformed(evt);
            }
        });
        Homing.add(Jcur, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 140, 320, 150));

        Jhelp.setText("help!");
        Jhelp.setBorder(null);
        Jhelp.setBorderPainted(false);
        Jhelp.setContentAreaFilled(false);
        Jhelp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JhelpActionPerformed(evt);
            }
        });
        Homing.add(Jhelp, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 320, 320, 150));

        dyk.setText("did you know");
        dyk.setBorder(null);
        dyk.setBorderPainted(false);
        dyk.setContentAreaFilled(false);
        Homing.add(dyk, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 390, 570, 80));

        jLabel2.setFont(new java.awt.Font("Nostalgic Whispers", 0, 14)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Save water, Save life");
        Homing.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 100, 130, -1));

        darkmode.setBackground(new java.awt.Color(255, 255, 255));
        darkmode.setFont(new java.awt.Font("Sarasvati", 0, 12)); // NOI18N
        darkmode.setText("Darkmode");
        darkmode.setBorder(null);
        darkmode.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/moon_12080286.png"))); // NOI18N
        darkmode.setIconTextGap(10);
        darkmode.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Signup/moon.png"))); // NOI18N
        darkmode.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                darkmodeMouseClicked(evt);
            }
        });
        darkmode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                darkmodeActionPerformed(evt);
            }
        });
        Homing.add(darkmode, new org.netbeans.lib.awtextra.AbsoluteConstraints(108, 545, 110, 50));
        Homing.add(white2, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 140, 320, 150));
        Homing.add(white1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 140, 580, 220));
        Homing.add(white3, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 320, 320, 150));
        Homing.add(white4, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 390, 570, 80));
        Homing.add(ressss5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 460, 70, 70));

        feedback3.setRoundBottomLeft(50);
        feedback3.setRoundBottomRight(50);
        feedback3.setRoundTopLeft(50);
        feedback3.setRoundTopRight(50);
        Homing.add(feedback3, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 540, 180, 70));
        Homing.add(ressss3, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 600, 110, 110));

        white7.setBackground(new java.awt.Color(0, 0, 0));
        Homing.add(white7, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 540, 120, 60));

        feedback5.setAutoscrolls(true);
        feedback5.setRoundBottomLeft(50);
        feedback5.setRoundBottomRight(50);
        feedback5.setRoundTopLeft(50);
        feedback5.setRoundTopRight(50);
        feedback5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                feedback5MouseClicked(evt);
            }
        });
        Homing.add(feedback5, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 540, 180, 70));
        feedback5.getAccessibleContext().setAccessibleName("s");

        feedback6.setRoundBottomLeft(50);
        feedback6.setRoundBottomRight(50);
        feedback6.setRoundTopLeft(50);
        feedback6.setRoundTopRight(50);
        Homing.add(feedback6, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 540, 180, 70));
        Homing.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 450, -1, -1));

        hometabb.add(Homing, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 2, 1050, 671));

        tab.addTab("Home", hometabb);

        Dashhh.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        Dashhh.add(circleee1, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 120, 260, 260));

        jButton2.setText("Weekly/Monthly  Water Usage");
        jButton2.setContentAreaFilled(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        Dashhh.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 550, 240, 30));

        jButton3.setText("Water Usage");
        jButton3.setContentAreaFilled(false);
        Dashhh.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 480, 240, 30));
        Dashhh.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 110, -1, -1));
        Dashhh.add(conserved1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 130, 340, 240));

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Chart");
        Dashhh.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 90, 140, 30));
        Dashhh.add(white5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 910, 320));
        Dashhh.add(white8, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 440, 410, 200));

        tab.addTab("Dashboard", Dashhh);

        Resultt.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tiwat.setFont(new java.awt.Font("Classy Vogue", 1, 24)); // NOI18N
        tiwat.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tiwat.setText("Water Consumption");
        Resultt.add(tiwat, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 40, 590, -1));

        TA1.setColumns(20);
        TA1.setFont(new java.awt.Font("Nostalgic Whispers", 0, 18)); // NOI18N
        TA1.setLineWrap(true);
        TA1.setRows(5);
        TA1.setBorder(null);
        TA1.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        TA1.setDragEnabled(true);
        TA1.setDropMode(javax.swing.DropMode.INSERT);
        TA1.setFocusable(false);
        t1.setViewportView(TA1);

        Resultt.add(t1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 100, 270, 180));

        TA2.setColumns(20);
        TA2.setFont(new java.awt.Font("Nostalgic Whispers", 0, 18)); // NOI18N
        TA2.setLineWrap(true);
        TA2.setRows(5);
        TA2.setBorder(null);
        TA2.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        TA2.setDragEnabled(true);
        TA2.setDropMode(javax.swing.DropMode.INSERT);
        TA2.setFocusable(false);
        t2.setViewportView(TA2);

        Resultt.add(t2, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 100, 270, 180));

        TA3.setColumns(20);
        TA3.setFont(new java.awt.Font("Nostalgic Whispers", 0, 18)); // NOI18N
        TA3.setLineWrap(true);
        TA3.setRows(5);
        TA3.setBorder(null);
        TA3.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        TA3.setDragEnabled(true);
        TA3.setDropMode(javax.swing.DropMode.INSERT);
        TA3.setFocusable(false);
        t3.setViewportView(TA3);

        Resultt.add(t3, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 100, 252, 180));

        Select.setFont(new java.awt.Font("Nostalgic Whispers", 0, 18)); // NOI18N
        Select.setText(">  Select Date  <");
        Select.setBorder(null);
        Select.setContentAreaFilled(false);
        Select.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelectActionPerformed(evt);
            }
        });
        Resultt.add(Select, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 330, 250, 40));

        daily.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        daily.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        daily.setText("DAILY");
        Resultt.add(daily, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 80, 230, 20));

        weekly.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        weekly.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        weekly.setText("WEEKLY");
        Resultt.add(weekly, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 80, 70, 20));

        monthly.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        monthly.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        monthly.setText("MONTHLY");
        Resultt.add(monthly, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 80, 150, 20));
        Resultt.add(topround2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 330, 250, 40));

        jButton9.setText("how it works");
        Resultt.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 370, 260, 260));

        getresult.setFont(new java.awt.Font("Home Video", 0, 22)); // NOI18N
        getresult.setText("Get Result");
        getresult.setBorder(null);
        getresult.setContentAreaFilled(false);
        getresult.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getresult.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                getresultActionPerformed(evt);
            }
        });
        Resultt.add(getresult, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 420, 190, 40));
        Resultt.add(white6, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 40, 810, 240));

        Wotco.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        Wotco.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Resultt.add(Wotco, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 320, 230, 40));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Water consumption (m³)");
        Resultt.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 290, 210, -1));

        calendar2.setOpaque(false);
        calendar2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                calendar2MouseClicked(evt);
            }
        });
        Resultt.add(calendar2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 370, 250, 270));
        Resultt.add(white9, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 420, 190, 40));
        Resultt.add(topround3, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 330, 260, 40));

        tab.addTab("Result", Resultt);

        Cons.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        tab.addTab("Conserved", Cons);

        Tips.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setText("Whyyy");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        Tips.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 70, 410, 120));

        tab.addTab("Tips", Tips);
        tab.addTab("tab6", sharpsidesett1);

        Tabunder.add(tab, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -38, 1050, 700));

        getContentPane().add(Tabunder, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 40, 1050, 660));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void quitMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_quitMouseDragged
    }//GEN-LAST:event_quitMouseDragged

    private void quitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_quitMouseClicked
       int response = JOptionPane.showConfirmDialog(
        this, 
        "Are you sure you want to exit?", 
        "Confirm Exit", 
        JOptionPane.YES_NO_OPTION, 
        JOptionPane.QUESTION_MESSAGE
    );

    if (response == JOptionPane.YES_OPTION) {
        // Close the window and exit the program
        System.exit(0);
    }
    }//GEN-LAST:event_quitMouseClicked

    private void notifActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_notifActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_notifActionPerformed

    private void menuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuActionPerformed

    }//GEN-LAST:event_menuActionPerformed

    private void menuMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuMouseDragged
        // TODO add your handling code here:
    }//GEN-LAST:event_menuMouseDragged

    private void LogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogoutActionPerformed
        int response = JOptionPane.showConfirmDialog(
            this, "Are you sure you want to log out?",
            "Logout Confirmation",
            JOptionPane.YES_NO_OPTION
        );

        if (response == JOptionPane.YES_OPTION) {
            // Perform logout logic, e.g., navigate to a login screen
            new window().setVisible(true); // Assuming 'window' is your login screen
            this.dispose();
        }
    }//GEN-LAST:event_LogoutActionPerformed

    private void settingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_settingActionPerformed
        dashlab2.setText("SETTINGS");
        dashlab2.setForeground(Color.WHITE); // Change the text color to green
        dashlab2.setFont(new java.awt.Font("Home Video", java.awt.Font.ITALIC, 38));
        tab.setSelectedIndex(5); // Navigate to the "dashboard" tab (index starts from 0)
    }//GEN-LAST:event_settingActionPerformed

    private void tipsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tipsMouseClicked
        dashlab2.setText("TIPS");
        dashlab2.setForeground(Color.WHITE); // Change the text color to green
        dashlab2.setFont(new java.awt.Font("Home Video", java.awt.Font.ITALIC, 38));
        tab.setSelectedIndex(4);
    }//GEN-LAST:event_tipsMouseClicked

    private void conservedMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_conservedMouseClicked
        dashlab2.setText("CONSERVED");
        dashlab2.setForeground(Color.WHITE); // Change the text color to green
        dashlab2.setFont(new java.awt.Font("Home Video", java.awt.Font.ITALIC, 38));
        tab.setSelectedIndex(3); // Navigate to the "dashboard" tab (index starts from 0)
    }//GEN-LAST:event_conservedMouseClicked

    private void resultActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resultActionPerformed

    }//GEN-LAST:event_resultActionPerformed

    private void resultMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_resultMouseClicked
        dashlab2.setText("CONVERT");
        dashlab2.setForeground(Color.WHITE); // Change the text color to green
        dashlab2.setFont(new java.awt.Font("Home Video", java.awt.Font.ITALIC, 38));
        tab.setSelectedIndex(2);
    }//GEN-LAST:event_resultMouseClicked

    private void dashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dashboardActionPerformed

    }//GEN-LAST:event_dashboardActionPerformed

    private void dashboardMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dashboardMouseClicked
        dashlab2.setText("DASHBOARD");
        dashlab2.setForeground(Color.WHITE); // Change the text color to green
        dashlab2.setFont(new java.awt.Font("Home Video", java.awt.Font.ITALIC, 38));
        tab.setSelectedIndex(1);
    }//GEN-LAST:event_dashboardMouseClicked

    private void homeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseClicked
        dashlab2.setText("HOME");
        dashlab2.setForeground(Color.WHITE); // Change the text color to green
        dashlab2.setFont(new java.awt.Font("Home Video", java.awt.Font.ITALIC, 38));
        tab.setSelectedIndex(0);
    }//GEN-LAST:event_homeMouseClicked

    private void conservedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_conservedActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_conservedActionPerformed

    private void tipsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tipsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tipsActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void JhelpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JhelpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_JhelpActionPerformed

    private void JcurActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JcurActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_JcurActionPerformed

    private void SelectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelectActionPerformed
 if (calendarPopup == null) {
        // Create a popup menu to display the calendar
        calendarPopup = new javax.swing.JPopupMenu();
        calendarPopup.add(calendar2); // Add the calendar component to the popup

        // Attach a MouseListener to handle date selection
        calendar2.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                calendar2MouseClicked(evt);
            }
        });
    }

    // Toggle the visibility of the popup
    if (calendarPopup.isVisible()) {
        calendarPopup.setVisible(false); // Hide the popup if already visible
    } else {
        calendarPopup.show(Select, 0, Select.getHeight()); // Show the popup below the button
    }
    }//GEN-LAST:event_SelectActionPerformed
    private void getresultActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_getresultActionPerformed
    // Always fetch the selected date directly from the calendar
    selectedDate = calendar2.getSelectedDate();

    if (selectedDate == null) {
        TA1.setText("");
        TA2.setText("");
        TA3.setText("");
        JOptionPane.showMessageDialog(this, "         Please select date", "ERROR", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Retrieve the water consumption input
    String waterInput = Wotco.getText().trim();

    if (waterInput.isEmpty()) {
        JOptionPane.showMessageDialog(this, "     Invalid water consumption input", "ERROR", JOptionPane.INFORMATION_MESSAGE);
        TA1.setText("");
        TA2.setText("");
        TA3.setText("");
        return;
    }

     try {
        // Parse the water consumption value
        double waterConsumption = Double.parseDouble(waterInput);

        // Calculate water consumption metrics
        double dailyConsumption = waterConsumption / 30; // Approximate daily consumption
        double weeklyConsumption = dailyConsumption * 7;
        double monthlyConsumption = waterConsumption;

        // Format the selected date
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MMMM dd, yyyy");
        String formattedDate = sdf.format(selectedDate);
        
         // Update the Select button's text with the selected date
        Select.setText(formattedDate);
        
        // Extract the month from the selected date
        java.text.SimpleDateFormat monthFormat = new java.text.SimpleDateFormat("MMMM");
        String month = monthFormat.format(selectedDate);
        
        // Update the JLabel with the formatted text
        tiwat.setText("Water Consumption in month of " + month); // Update the JLabel text

        // Display results in the corresponding text areas
        TA1.setText(String.format("Daily Water Consumption:\n%.2f cubic meters", dailyConsumption));
        TA2.setText(String.format("Weekly Water Consumption:\n%.2f cubic meters", weeklyConsumption));
        TA3.setText(String.format("Monthly Water Consumption:\n%.2f cubic meters", monthlyConsumption));

    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(this, "Invalid water consumption input \n        Please enter a number", "ERROR", JOptionPane.INFORMATION_MESSAGE);
        TA1.setText("");
        TA2.setText("");
        TA3.setText("");
    }
    }//GEN-LAST:event_getresultActionPerformed

    private void homeMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMousePressed
        home.setFont(new java.awt.Font("Wonderful Future", java.awt.Font.BOLD, 18));
    }//GEN-LAST:event_homeMousePressed

    private void homeMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseReleased
        home.setFont(new java.awt.Font("Wonderful Future", java.awt.Font.PLAIN, 20));
    }//GEN-LAST:event_homeMouseReleased

    private void dashboardMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dashboardMousePressed
        dashboard.setFont(new java.awt.Font("Wonderful Future", java.awt.Font.BOLD, 18));
    }//GEN-LAST:event_dashboardMousePressed

    private void dashboardMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dashboardMouseReleased
        dashboard.setFont(new java.awt.Font("Wonderful Future", java.awt.Font.PLAIN, 20));
    }//GEN-LAST:event_dashboardMouseReleased

    private void resultMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_resultMousePressed
        result.setFont(new java.awt.Font("Wonderful Future", java.awt.Font.BOLD, 18));
    }//GEN-LAST:event_resultMousePressed

    private void resultMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_resultMouseReleased
        result.setFont(new java.awt.Font("Wonderful Future", java.awt.Font.PLAIN, 20));
    }//GEN-LAST:event_resultMouseReleased

    private void tipsMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tipsMousePressed
        tips.setFont(new java.awt.Font("Wonderful Future", java.awt.Font.BOLD, 18));
    }//GEN-LAST:event_tipsMousePressed

    private void tipsMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tipsMouseReleased
        tips.setFont(new java.awt.Font("Wonderful Future", java.awt.Font.PLAIN, 20));
    }//GEN-LAST:event_tipsMouseReleased

    private void JHisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JHisActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_JHisActionPerformed

    private void darkmodeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_darkmodeMouseClicked

    }//GEN-LAST:event_darkmodeMouseClicked

    private void darkmodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_darkmodeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_darkmodeActionPerformed

    private void calendar2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_calendar2MouseClicked

    }//GEN-LAST:event_calendar2MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Jpopf popwin = new Jpopf();
            popwin.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void feedback5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_feedback5MouseClicked
        dashlab2.setText("TIPS");
        dashlab2.setForeground(Color.WHITE); // Change the text color to green
        dashlab2.setFont(new java.awt.Font("Home Video", java.awt.Font.ITALIC, 38));
        tab.setSelectedIndex(4);
    }//GEN-LAST:event_feedback5MouseClicked
private void initializeCalendarDialog() {
    calendarDialog = new javax.swing.JDialog(this, "Select Date", true);
    calendarDialog.setSize(250, 270);
    calendarDialog.setLayout(new BorderLayout());
    calendarDialog.add(calendar2, BorderLayout.CENTER);
    calendarDialog.setDefaultCloseOperation(javax.swing.WindowConstants.HIDE_ON_CLOSE);
    calendarDialog.setLocationRelativeTo(this);

    calendar2.setPreferredSize(new java.awt.Dimension(250, 270));
    calendar2.addMouseListener(new java.awt.event.MouseAdapter() {
        @Override
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            fetchSelectedDateFromCalendar();
            calendarDialog.setVisible(false);
        }
    });
}
private void fetchSelectedDateFromCalendar() {
    // Get the selected date from the calendar
    selectedDate = calendar2.getSelectedDate();

    if (selectedDate != null) {
        // Format the selected date
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MMMM dd, yyyy");
        String formattedDate = sdf.format(selectedDate);

        // Update the text area
        TA2.setText("Selected Date: " + formattedDate + "\n");
    } else {
        TA2.setText("No date selected. Please try again.\n");
    }
}
    
     public static void main(String args[]) {
       java.awt.EventQueue.invokeLater(()->{
           new Sign().setVisible(true); 
       });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private swing.conserved Cons;
    private swing.conserved Dashhh;
    private swing.conserved Homing;
    private javax.swing.JButton JHis;
    private javax.swing.JButton Jcur;
    private javax.swing.JButton Jhelp;
    private javax.swing.JButton Logout;
    private swing.conserved Resultt;
    private javax.swing.JButton Select;
    private javax.swing.JTextArea TA1;
    private javax.swing.JTextArea TA2;
    private javax.swing.JTextArea TA3;
    private javax.swing.JPanel Tabunder;
    private swing.conserved Tips;
    private javax.swing.JTextField Wotco;
    private raven.calendar.Calendar calendar2;
    private swing.circleee circleee1;
    private javax.swing.JButton conserved;
    private swing.conserved conserved1;
    private javax.swing.JLabel daily;
    private javax.swing.JCheckBox darkmode;
    private javax.swing.JButton dashboard;
    private javax.swing.JLabel dashlab2;
    private javax.swing.JButton dyk;
    private swing.feedback feedback3;
    private swing.feedback feedback5;
    private swing.feedback feedback6;
    public javax.swing.JButton getresult;
    private swing.GruPanel gruPanel1;
    private swing.GruPanel gruPanel2;
    private javax.swing.JButton home;
    private javax.swing.JPanel hometabb;
    private swing.RoundPanel iconplaced;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JButton menu;
    private javax.swing.JLabel monthly;
    private javax.swing.JButton notif;
    private javax.swing.JButton quit;
    private swing.ressss ressss1;
    private swing.ressss ressss3;
    private swing.ressss ressss5;
    private javax.swing.JButton result;
    private javax.swing.JButton setting;
    private swing.sharpsidesett sharpsidesett1;
    private swing.sidedddd sidedddd1;
    private swing.sidedddd sidedddd2;
    private javax.swing.JScrollPane t1;
    private javax.swing.JScrollPane t2;
    private javax.swing.JScrollPane t3;
    private javax.swing.JTabbedPane tab;
    private javax.swing.JButton tips;
    private javax.swing.JLabel tiwat;
    private swing.topround topround2;
    private swing.topround topround3;
    private swing.GruPanel upperpane;
    private javax.swing.JLabel weekly;
    private swing.white white1;
    private swing.white white2;
    private swing.white white3;
    private swing.white white4;
    private swing.white white5;
    private swing.white white6;
    private swing.white white7;
    private swing.white white8;
    private swing.white white9;
    // End of variables declaration//GEN-END:variables
}
